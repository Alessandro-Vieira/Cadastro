# Tutorial Django - Cadastro e Login de usuários apenas com e-mail e senha

Código de dois artigos:  
- [Criando um modelo de usuário personalizado](https://www.fabioruicci.com.br/artigos/tutorial-django-criando-um-modelo-de-usuario-personalizado-custom-user-model/).
- [Cadastro e login de usuários apenas com e-mail e senha](https://www.fabioruicci.com.br/artigos/tutorial-django-cadastro-e-login-de-usuarios-apenas-com-e-mail-e-senha/).
